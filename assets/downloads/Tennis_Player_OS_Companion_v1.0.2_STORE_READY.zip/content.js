
const TPOS_COMPANION_VERSION = '1.0.2';
const PENDING_KEY = 'tposPendingImport.v1';
const TPOS_MESSAGE_SOURCE = 'TPOS_COMPANION_EXTENSION';
const WEBAPP_MESSAGE_SOURCE = 'TPOS_WEBAPP';
const DEFAULT_TPOS_URL = 'https://tennis.polidorionline.it/#/opponents';

const clean = value => String(value ?? '')
  .replace(/\u00a0/g, ' ')
  .replace(/\s+/g, ' ')
  .trim();

function isTennisTalkerPage() {
  return /(^|\.)tennistalker\.it$/i.test(location.hostname);
}


function isTposPage() {
  const path = location.pathname.toLowerCase();
  return (
    location.hostname === 'tennis.polidorionline.it'
    || (location.hostname === 'teodorostudita.github.io' && path.startsWith('/tennis-player-os'))
    || location.hostname === 'localhost'
    || location.hostname === '127.0.0.1'
  );
}

function playerUrl(href = '') {
  try {
    const url = new URL(href, location.href);
    const match = url.pathname.match(/^\/giocatore\/(\d+)\/?$/i);
    if (!match) return null;
    return {
      externalId: match[1],
      url: `${url.origin}/giocatore/${match[1]}`,
    };
  } catch {
    return null;
  }
}

function countPlayerLinks(node) {
  try {
    return node.querySelectorAll?.('a[href*="/giocatore/"]').length || 0;
  } catch {
    return 0;
  }
}

function rowFor(anchor) {
  let node = anchor;
  let best = anchor.parentElement || anchor;

  for (let depth = 0; node && depth < 7; depth += 1, node = node.parentElement) {
    const text = clean(node.innerText || node.textContent || '');
    const linkCount = countPlayerLinks(node);

    if (text && linkCount >= 1 && linkCount <= 2) {
      best = node;
    }

    if (/#\s*\d{1,6}\b/.test(text) && linkCount >= 1 && linkCount <= 2) {
      return node;
    }
  }

  return best;
}

function parseTail(text = '') {
  const value = clean(text);

  let match = value.match(
    /^(.+?)\s+([A-Z]{3})\s*\(([A-Z]{2})\)\s*(?:-\s*(.*))?$/
  );
  if (match) {
    return {
      name: clean(match[1]),
      region: match[2],
      province: match[3],
      club: clean(match[4] || ''),
    };
  }

  match = value.match(/^(.+?)\s+([A-Z]{3})\s*(?:-\s*(.*))?$/);
  if (match) {
    return {
      name: clean(match[1]),
      region: match[2],
      province: '',
      club: clean(match[3] || ''),
    };
  }

  const parts = value.split(/\s+-\s+/);
  return {
    name: clean(parts.shift() || value),
    region: '',
    province: '',
    club: clean(parts.join(' - ')),
  };
}

function parseAnchor(anchor, fallbackRank) {
  const link = playerUrl(anchor.getAttribute('href') || anchor.href || '');
  if (!link) return null;

  const row = rowFor(anchor);
  const rowText = clean(row?.innerText || row?.textContent || '');
  const anchorText = clean(anchor.innerText || anchor.textContent || '');

  const rank =
    Number(rowText.match(/#\s*(\d{1,6})\b/)?.[1])
    || Number(anchorText.match(/#\s*(\d{1,6})\b/)?.[1])
    || fallbackRank;

  const full = rowText.match(
    /#\s*(\d{1,6})\s*([1-4]\.(?:NC|[1-9]))\s*(U(?:08|10|12|14|16|18)|NOR|NOF|O\d{2})?\s+(.+?)\s+([A-Z]{3})\s*\(([A-Z]{2})\)\s*(?:-\s*(.*))?$/i
  );

  if (full) {
    return {
      rank: Number(full[1]) || rank,
      fitpRanking: String(full[2] || '').toUpperCase(),
      category: String(full[3] || '').toUpperCase(),
      name: clean(full[4]),
      region: String(full[5] || '').toUpperCase(),
      province: String(full[6] || '').toUpperCase(),
      club: clean(full[7] || ''),
      externalId: link.externalId,
      url: link.url,
      raw: rowText,
    };
  }

  const playerText = anchorText.replace(/^#\s*\d{1,6}\s*/, '');
  const head = playerText.match(
    /^([1-4]\.(?:NC|[1-9]))\s*(U(?:08|10|12|14|16|18)|NOR|NOF|O\d{2})?\s+(.+)$/i
  );

  if (!head) {
    const tail = parseTail(playerText);
    return {
      rank,
      fitpRanking: '',
      category: '',
      ...tail,
      externalId: link.externalId,
      url: link.url,
      raw: rowText,
      partial: true,
    };
  }

  const tail = parseTail(head[3]);
  return {
    rank,
    fitpRanking: String(head[1] || '').toUpperCase(),
    category: String(head[2] || '').toUpperCase(),
    ...tail,
    externalId: link.externalId,
    url: link.url,
    raw: rowText,
  };
}

function scanTennisTalkerPage() {
  const anchors = [...document.querySelectorAll('a[href*="/giocatore/"]')];
  const seen = new Set();
  const players = [];
  const diagnostics = [];

  for (const anchor of anchors) {
    const link = playerUrl(anchor.getAttribute('href') || anchor.href || '');
    if (!link || seen.has(link.externalId)) continue;
    seen.add(link.externalId);

    const player = parseAnchor(anchor, players.length + 1);
    if (player?.name) players.push(player);

    if (diagnostics.length < 12) {
      const row = rowFor(anchor);
      diagnostics.push({
        href: link.url,
        anchorText: clean(anchor.innerText || anchor.textContent || ''),
        containerText: clean(row?.innerText || row?.textContent || '').slice(0, 500),
        tag: row?.tagName || '',
        className: clean(row?.className || '').slice(0, 200),
      });
    }
  }

  players.sort((a, b) => Number(a.rank || 999999) - Number(b.rank || 999999));

  const bodyText = clean(document.body?.innerText || '');
  return {
    ok: true,
    version: TPOS_COMPANION_VERSION,
    scannedAt: new Date().toISOString(),
    page: {
      url: location.href,
      title: document.title,
      filteredCount: bodyText.match(/([\d.]+)\s+Giocatori filtrati/i)?.[1] || '',
    },
    count: players.length,
    categories: [...new Set(players.map(player => player.category).filter(Boolean))],
    players,
    diagnostics,
  };
}


function tennisTalkerPlayerId() {
  return location.pathname.match(/^\/giocatore\/(\d+)\/?$/i)?.[1] || '';
}

function pageLines() {
  return String(document.body?.innerText || '')
    .split(/\n+/)
    .map(clean)
    .filter(Boolean);
}

function firstValueAfterLabel(lines, label, validator = null) {
  const wanted = clean(label).toLocaleLowerCase('it-IT');

  for (let index = 0; index < lines.length; index += 1) {
    if (lines[index].toLocaleLowerCase('it-IT') !== wanted) continue;

    for (let offset = 1; offset <= 4 && index + offset < lines.length; offset += 1) {
      const value = clean(lines[index + offset]);
      if (!value || value === ',' || value === '-') continue;
      if (!validator || validator(value)) return value;
    }
  }

  return '';
}

function normalizeBackhand(value = '') {
  const text = clean(value).toLocaleLowerCase('it-IT');
  if (!text) return '';
  if (text.includes('bimane') || text.includes('due mani')) return 'Due mani';
  if (text.includes('monomane') || text.includes('una mano')) return 'Una mano';
  return clean(value).replace(/^Rovescio\s+/i, '');
}

function parseStrengths(lines) {
  const start = lines.findIndex(line => line === 'Punti di Forza');
  if (start < 0) return {};

  let end = lines.findIndex(
    (line, index) => index > start && line.startsWith('Analisi Avanzata')
  );
  if (end < 0) end = Math.min(lines.length, start + 40);

  const section = lines.slice(start + 1, end);
  const labels = {
    'Dritto': 'forehand',
    'Rovescio': 'backhand',
    'Servizio': 'serve',
    'Volée': 'volley',
    'Tenuta fisica': 'physical',
    'Tenuta mentale': 'mental',
  };

  const strengths = {};

  for (let index = 0; index < section.length; index += 1) {
    const key = labels[section[index]];
    if (!key) continue;

    const next = section.slice(index + 1, index + 4)
      .find(value => /^\d{1,3}%$/.test(value));

    if (next) strengths[key] = Number(next.replace('%', ''));
  }

  return strengths;
}


function normalizePlayerName(value = '') {
  const name = clean(value);
  if (!name) return '';

  const letters = name.replace(/[^A-Za-zÀ-ÖØ-öø-ÿ]/g, '');
  if (!letters || name !== name.toUpperCase()) return name;

  return name
    .toLocaleLowerCase('it-IT')
    .split(/\s+/)
    .map(word => word ? `${word.charAt(0).toLocaleUpperCase('it-IT')}${word.slice(1)}` : '')
    .join(' ');
}


function playerNameKey(value = '') {
  return normalizePlayerName(value)
    .toLocaleLowerCase('it-IT')
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .split(/\s+/)
    .filter(Boolean)
    .sort()
    .join('|');
}


function documentLines(doc = document) {
  const body = doc?.body;
  if (!body) return [];

  const source = typeof body.innerText === 'string' && body.innerText.trim()
    ? body.innerText
    : body.textContent || '';

  return String(source)
    .split(/\n+/)
    .map(clean)
    .filter(Boolean);
}

function playerDescriptor(text = '') {
  const value = clean(text);
  const match = value.match(
    /^([1-4]\.(?:NC|[1-9]))\s*(U(?:08|10|12|14|16|18)|NOR|NOF|O\d{2})\s+(.+)$/i
  );

  if (!match) return null;

  return {
    fitpRanking: String(match[1] || '').toUpperCase(),
    category: String(match[2] || '').toUpperCase(),
    name: normalizePlayerName(match[3] || ''),
  };
}

function scoreLike(value = '') {
  const text = clean(value);
  if (!text) return false;
  if (text === '0') return true;

  if (!/^[0-9\s\-\/()]+$/.test(text)) return false;
  if (!/\d/.test(text)) return false;

  // Avoid interpreting a year/date/ranking line as a tennis score.
  if (/^(19|20)\d{2}$/.test(text)) return false;
  if (/^\d{1,2}[\/\-]\d{1,2}[\/\-](?:\d{2}|\d{4})$/.test(text)) return false;

  return text.length <= 40;
}

function dateFromLines(lines = []) {
  for (const line of lines) {
    let match = line.match(/\b(\d{2})[\/\-.](\d{2})[\/\-.](\d{4})\b/);
    if (match) return `${match[3]}-${match[2]}-${match[1]}`;

    match = line.match(/\b(20\d{2})[\/\-.](\d{2})[\/\-.](\d{2})\b/);
    if (match) return `${match[1]}-${match[2]}-${match[3]}`;
  }

  return '';
}

function normalizeMatchResult(value = '') {
  const result = clean(value).toUpperCase();
  if (result === 'V' || result === 'W' || result === 'VITTORIA') return 'W';
  if (result === 'S' || result === 'L' || result === 'SCONFITTA') return 'L';
  return '';
}

function surfaceFromLines(lines = []) {
  const text = lines.join(' ').toLocaleLowerCase('it-IT');

  if (text.includes('terra rossa') || /\bterra\b/.test(text)) return 'Terra';
  if (text.includes('cemento') || text.includes('hard')) return 'Hard';
  if (text.includes('erba')) return 'Erba';
  if (text.includes('sintetico')) return 'Sintetico';

  return '';
}

function playerLinkInfo(anchor) {
  const link = playerUrl(anchor.getAttribute('href') || anchor.href || '');
  if (!link) return null;

  const descriptor = playerDescriptor(anchor.innerText || anchor.textContent || '');

  return {
    externalId: link.externalId,
    url: link.url,
    name: descriptor?.name || normalizePlayerName(anchor.innerText || anchor.textContent || ''),
    fitpRanking: descriptor?.fitpRanking || '',
    category: descriptor?.category || '',
  };
}

function matchContainerFor(anchor, selfExternalId) {
  let node = anchor.parentElement;
  let best = null;

  for (let depth = 0; node && depth < 9; depth += 1, node = node.parentElement) {
    const links = [...node.querySelectorAll('a[href*="/giocatore/"]')]
      .map(playerLinkInfo)
      .filter(Boolean);

    const ids = [...new Set(links.map(item => item.externalId))];
    if (!ids.includes(selfExternalId)) continue;
    if (ids.length < 2 || ids.length > 4) continue;

    const lines = String(node.innerText || node.textContent || '')
      .split(/\n+/)
      .map(clean)
      .filter(Boolean);

    const hasScore = lines.some(scoreLike);
    if (!hasScore) continue;

    best = node;

    // Prefer the smallest sensible singles card.
    if (ids.length === 2 && lines.length <= 18) break;
  }

  return best;
}

function parseMatchContainer(container, profile) {
  if (!container) return null;

  const lines = String(container.innerText || container.textContent || '')
    .split(/\n+/)
    .map(clean)
    .filter(Boolean);

  const linkedPlayers = [...container.querySelectorAll('a[href*="/giocatore/"]')]
    .map(playerLinkInfo)
    .filter(Boolean);

  const byId = new Map();
  linkedPlayers.forEach(item => {
    if (!byId.has(item.externalId)) byId.set(item.externalId, item);
  });

  const players = [...byId.values()];

  // Conservative: singles only.
  if (players.length !== 2) return null;
  if (!players.some(item => item.externalId === profile.externalId)) return null;

  const opponent = players.find(item => item.externalId !== profile.externalId);
  if (!opponent) return null;

  const resultLine = lines.find(line =>
    ['V', 'S', 'W', 'L', 'Vittoria', 'Sconfitta'].includes(line)
  );
  const result = normalizeMatchResult(resultLine);

  const score = lines.find(scoreLike) || '';
  const date = dateFromLines(lines);
  const surface = surfaceFromLines(lines);

  const ignored = new Set([
    clean(resultLine),
    clean(score),
    ...players.flatMap(player => [
      clean(player.name),
      clean(`${player.fitpRanking}${player.category} ${player.name}`),
      clean(`${player.fitpRanking} ${player.category} ${player.name}`),
    ]),
  ]);

  const tournamentCandidates = lines.filter(line => {
    if (!line || ignored.has(line)) return false;
    if (date && line.includes(date)) return false;
    if (/^(?:Partite|Ultime partite|Vedi tutte|Vedi tutte le statistiche)$/i.test(line)) return false;
    if (scoreLike(line)) return false;
    if (playerDescriptor(line)) return false;
    if (['V', 'S', 'W', 'L', 'Vittoria', 'Sconfitta'].includes(line)) return false;
    return line.length >= 5;
  });

  const tournament = tournamentCandidates.find(line =>
    /torneo|campionat|open|under|qualific|master|trofeo|challenge|circuit/i.test(line)
  ) || '';

  const raw = lines.join(' | ').slice(0, 1200);
  const externalKey = [
    'tt',
    profile.externalId,
    opponent.externalId,
    date,
    clean(score),
    result,
    clean(tournament),
    raw.slice(0, 240),
  ].join('|');

  return {
    externalKey,
    date,
    result,
    opponentName: opponent.name,
    opponentExternalId: opponent.externalId,
    opponentUrl: opponent.url,
    opponentFitpRanking: opponent.fitpRanking,
    opponentCategory: opponent.category,
    score: clean(score),
    tournament: clean(tournament),
    surface,
    raw,
  };
}

function parseMatchCardsFromDocument(doc, profile) {
  const anchors = [...doc.querySelectorAll('a[href*="/giocatore/"]')];
  const matches = [];
  const seenContainers = new Set();
  const seenKeys = new Set();

  for (const anchor of anchors) {
    const link = playerLinkInfo(anchor);
    if (!link) continue;

    const container = matchContainerFor(anchor, profile.externalId);
    if (!container || seenContainers.has(container)) continue;
    seenContainers.add(container);

    const match = parseMatchContainer(container, profile);
    if (!match || seenKeys.has(match.externalKey)) continue;

    seenKeys.add(match.externalKey);
    matches.push(match);
  }

  return matches;
}

function parseRecentMatchesFromOverview(profile) {
  const lines = pageLines();
  const start = lines.findIndex(line => line === 'Ultime partite');
  if (start < 0) return [];

  let end = lines.findIndex(
    (line, index) => index > start && (
      line === 'Vedi tutte'
      || line.startsWith('Tornei a cui partecipa')
    )
  );
  if (end < 0) end = Math.min(lines.length, start + 80);

  const section = lines.slice(start + 1, end);
  const matches = [];
  let current = null;

  const flush = () => {
    if (!current) return;

    const descriptors = current.lines
      .map(playerDescriptor)
      .filter(Boolean);

    // We only accept unambiguous singles rows.
    if (descriptors.length === 2) {
      const selfIndex = descriptors.findIndex(item =>
        clean(item.name).toLocaleLowerCase('it-IT')
          === clean(profile.name).toLocaleLowerCase('it-IT')
      );

      const opponent = descriptors[selfIndex === 0 ? 1 : 0];
      if (opponent) {
        const score = current.lines.find(scoreLike) || '';
        const raw = current.lines.join(' | ').slice(0, 800);
        const externalKey = [
          'tt-overview',
          profile.externalId,
          clean(opponent.name).toLocaleLowerCase('it-IT'),
          clean(score),
          current.result,
          raw.slice(0, 200),
        ].join('|');

        matches.push({
          externalKey,
          date: '',
          result: current.result,
          opponentName: opponent.name,
          opponentExternalId: '',
          opponentUrl: '',
          opponentFitpRanking: opponent.fitpRanking,
          opponentCategory: opponent.category,
          score: clean(score),
          tournament: '',
          surface: '',
          raw,
        });
      }
    }

    current = null;
  };

  for (const line of section) {
    const result = normalizeMatchResult(line);

    if (result && ['V', 'S', 'W', 'L'].includes(clean(line).toUpperCase())) {
      flush();
      current = { result, lines: [] };
      continue;
    }

    if (current) current.lines.push(line);
  }

  flush();

  return matches;
}

async function fetchFullMatchHistory(profile) {
  const matchesUrl = `${location.origin}/giocatore/${profile.externalId}/partite`;

  try {
    const response = await fetch(matchesUrl, {
      method: 'GET',
      credentials: 'include',
      headers: {
        Accept: 'text/html,application/xhtml+xml',
      },
    });

    if (!response.ok) {
      return {
        ok: false,
        url: matchesUrl,
        status: response.status,
        matches: [],
        reason: `HTTP ${response.status}`,
      };
    }

    const html = await response.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const matches = parseMatchCardsFromDocument(doc, profile);

    return {
      ok: matches.length > 0,
      url: matchesUrl,
      status: response.status,
      htmlLength: html.length,
      matches,
      reason: matches.length ? '' : 'Nessun match strutturato riconosciuto nella pagina Partite.',
    };
  } catch (error) {
    return {
      ok: false,
      url: matchesUrl,
      status: 0,
      matches: [],
      reason: error?.message || String(error),
    };
  }
}

function matchPageIdentity() {
  const playerMatch = location.pathname.match(/^\/giocatore\/(\d+)\/partite\/?$/i);
  const ownProfile = /^\/profilo\/partite\/?$/i.test(location.pathname);

  if (!playerMatch && !ownProfile) return null;

  const titleMatch = clean(document.title).match(/^Partite di\s+(.+?)\s+-\s+TennisTalker$/i);
  const name = normalizePlayerName(titleMatch?.[1] || '');

  if (playerMatch) {
    return {
      externalId: playerMatch[1],
      externalUrl: `${location.origin}/giocatore/${playerMatch[1]}`,
      matchesUrl: location.href,
      name,
      isSelfProfile: false,
    };
  }

  const syntheticId = `self:${playerNameKey(name) || 'profile'}`;

  return {
    externalId: syntheticId,
    externalUrl: `${location.origin}/profilo`,
    matchesUrl: location.href,
    name,
    isSelfProfile: true,
  };
}

function parsePlayerDescriptorFull(value = '') {
  const text = clean(value);

  const match = text.match(
    /^([1-4]\.(?:NC|[1-9]))\s+((?:U(?:08|10|12|14|16|18)|NOR|NOF|O\d{2}))\s+(.+?)\s+([A-Z]{3})\s+\(([A-Z]{2})\)\s+-\s+(.+)$/i
  );

  if (!match) return null;

  return {
    fitpRanking: clean(match[1]).toUpperCase(),
    category: clean(match[2]).toUpperCase(),
    name: normalizePlayerName(match[3]),
    region: clean(match[4]).toUpperCase(),
    province: clean(match[5]).toUpperCase(),
    club: clean(match[6]),
  };
}


function parsePlayerDescriptorLoose(value = '') {
  const text = clean(value);
  if (!text) return null;

  const full = parsePlayerDescriptorFull(text);
  if (full) return full;

  const compact = text.match(
    /^([1-4]\.(?:NC|[1-9]))\s*((?:U(?:08|10|12|14|16|18)|NOR|NOF|O\d{2}))\s+(.+?)(?:\s+([A-Z]{3})\s+\(([A-Z]{2})\)(?:\s*-\s*(.+))?)?$/i
  );

  if (!compact) return null;

  return {
    fitpRanking: clean(compact[1]).toUpperCase(),
    category: clean(compact[2]).toUpperCase(),
    name: normalizePlayerName(compact[3]),
    region: clean(compact[4]).toUpperCase(),
    province: clean(compact[5]).toUpperCase(),
    club: clean(compact[6]),
  };
}

function playerDescriptorFromAnchor(anchor) {
  const text = clean(anchor?.innerText || anchor?.textContent || '');
  const parsed = parsePlayerDescriptorLoose(text);
  if (parsed) return parsed;

  const href = anchor?.href || anchor?.getAttribute?.('href') || '';
  if (!/\/giocatore\/\d+/i.test(href) || !text || text.length > 90) return null;

  return {
    fitpRanking: '',
    category: '',
    name: normalizePlayerName(text),
    region: '',
    province: '',
    club: '',
  };
}

function matchCardForOpponentAnchor(anchor, identity) {
  const anchorText = clean(anchor.innerText || anchor.textContent || '');
  if (!playerDescriptorFromAnchor(anchor)) return null;

  let node = anchor.parentElement;

  for (let depth = 0; node && depth < 8; depth += 1, node = node.parentElement) {
    const text = clean(node.innerText || node.textContent || '');

    // A real TennisTalker match card starts with:
    // V|S + points + the two player descriptors + score.
    // Do not compare the title name because TennisTalker may invert
    // surname/name between page title and match card.
    if (!/\b[VS]\s+\d+\s+punti\b/i.test(text)) continue;
    if (text.length > 1800) continue;
    if (!text.includes(anchorText)) continue;

    const descriptors = [...node.querySelectorAll('a[href*="/giocatore/"]')]
      .map(a => playerDescriptorFromAnchor(a))
      .filter(Boolean);

    // Prefer the smallest card-like node. One opponent anchor is enough:
    // the profiled player is often rendered as plain text, not as a link.
    if (descriptors.length >= 1) return node;
  }

  return null;
}

function trailingScoreFromMatchText(text = '') {
  const value = clean(text);
  const match = value.match(/(?:^|\s)((?:\d{1,2})(?:\s+\d{1,2}){0,5})$/);
  return clean(match?.[1] || '');
}


function italianDateToIso(value = '') {
  const match = clean(value).match(/\b(\d{2})\/(\d{2})\/(\d{4})\b/);
  if (!match) return '';

  return `${match[3]}-${match[2]}-${match[1]}`;
}

function dateMatches(text = '') {
  return [...clean(text).matchAll(/\b\d{2}\/\d{2}\/\d{4}\b/g)]
    .map(match => match[0]);
}

function nearestPrecedingDateElement(card) {
  const candidates = [...document.querySelectorAll('body *')];
  let best = null;

  for (const element of candidates) {
    if (element === card || element.contains(card)) continue;

    const text = clean(element.innerText || element.textContent || '');
    if (!text || text.length > 500) continue;
    if (!dateMatches(text).length) continue;

    const position = element.compareDocumentPosition(card);
    if (position & Node.DOCUMENT_POSITION_FOLLOWING) {
      best = element;
    }
  }

  return best;
}

function compactDateContext(element, card) {
  if (!element) return '';

  let best = clean(element.innerText || element.textContent || '');
  let node = element.parentElement;

  for (let depth = 0; node && depth < 4; depth += 1, node = node.parentElement) {
    if (node.contains(card)) break;

    const text = clean(node.innerText || node.textContent || '');
    if (!text || text.length > 500) break;
    if (!dateMatches(text).length) break;

    best = text;
  }

  return best;
}

function tournamentFromDateContext(text = '') {
  let value = clean(text);
  if (!value) return '';

  value = value
    .replace(/^P\.\s*vinte\s+\d+\s+/i, '')
    .replace(/^P\.\s*perse\s+\d+\s+/i, '')
    .replace(/\b\d{2}\/\d{2}\/\d{4}\b/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  // TennisTalker often appends the competition category after the date.
  value = value.replace(/\s+(?:OPEN|NOF|NOR|U(?:08|10|12|14|16|18)|O\d{2})$/i, '');

  return clean(value);
}

function surfaceFromText(value = '') {
  const text = clean(value).toLocaleLowerCase('it-IT');

  if (text.includes('terra rossa')) return 'Terra rossa';
  if (text.includes('cemento')) return 'Cemento';
  if (text.includes('hard court') || /\bhard\b/.test(text)) return 'Hard';
  if (text.includes('erba')) return 'Erba';
  if (text.includes('sintetico')) return 'Sintetico';
  if (text.includes('indoor')) return 'Indoor';

  return '';
}

function roundAndSurfaceContext(card) {
  let node = card;

  for (let depth = 0; node && depth < 8; depth += 1, node = node.parentElement) {
    let sibling = node.previousElementSibling;
    let checked = 0;

    while (sibling && checked < 4) {
      const text = clean(sibling.innerText || sibling.textContent || '');
      const surface = surfaceFromText(text);

      if (surface) {
        const round = clean(
          text
            .replace(/Terra rossa/ig, ' ')
            .replace(/Cemento/ig, ' ')
            .replace(/Hard court/ig, ' ')
            .replace(/\bHard\b/ig, ' ')
            .replace(/Erba/ig, ' ')
            .replace(/Sintetico/ig, ' ')
            .replace(/Indoor/ig, ' ')
            .replace(/\s+/g, ' ')
        );

        return {
          surface,
          round,
          raw: text,
        };
      }

      sibling = sibling.previousElementSibling;
      checked += 1;
    }
  }

  return {
    surface: '',
    round: '',
    raw: '',
  };
}

function matchMetadataFromDom(card) {
  const dateElement = nearestPrecedingDateElement(card);
  const dateContext = compactDateContext(dateElement, card);
  const date = italianDateToIso(dateContext);
  const tournament = tournamentFromDateContext(dateContext);
  const roundSurface = roundAndSurfaceContext(card);

  return {
    date,
    tournament,
    surface: roundSurface.surface,
    round: roundSurface.round,
    dateContext,
    roundContext: roundSurface.raw,
  };
}

function selfDescriptorFromMatchText(containerText, opponentText, score) {
  let rest = clean(containerText)
    .replace(/\b[VS]\s+\d+\s+punti\b/i, ' ');

  if (score && rest.endsWith(score)) {
    rest = clean(rest.slice(0, -score.length));
  }

  const opponentIndex = rest.indexOf(opponentText);
  if (opponentIndex >= 0) {
    rest = clean(
      `${rest.slice(0, opponentIndex)} ${rest.slice(opponentIndex + opponentText.length)}`
    );
  }

  return parsePlayerDescriptorLoose(rest);
}

function scanTennisTalkerMatchesPage() {
  const identity = matchPageIdentity();

  if (!identity) {
    return {
      ok: false,
      error: 'La pagina corrente non è lo storico partite di un giocatore TennisTalker.',
    };
  }

  const opponentAnchors = [...document.querySelectorAll('a[href*="/giocatore/"]')];
  const matches = [];
  const seenCards = new Set();
  const duplicateCounts = new Map();
  const rejected = [];
  let selfDescriptor = null;

  for (const anchor of opponentAnchors) {
    const href = anchor.href || anchor.getAttribute('href') || '';
    const opponentId = href.match(/\/giocatore\/(\d+)/i)?.[1] || '';

    if (!opponentId || opponentId === identity.externalId) continue;

    const opponent = playerDescriptorFromAnchor(anchor);
    if (!opponent) continue;

    if (
      identity.isSelfProfile
      && identity.name
      && playerNameKey(opponent.name) === playerNameKey(identity.name)
    ) {
      continue;
    }

    const card = matchCardForOpponentAnchor(anchor, identity);
    if (!card) {
      if (rejected.length < 12) {
        rejected.push({
          href,
          anchorText: clean(anchor.innerText || anchor.textContent || ''),
          reason: 'match-card-not-found',
        });
      }
      continue;
    }

    if (seenCards.has(card)) continue;
    seenCards.add(card);

    const text = clean(card.innerText || card.textContent || '');
    const resultLetter = text.match(/\b([VS])\s+\d+\s+punti\b/i)?.[1]?.toUpperCase() || '';
    const points = Number(text.match(/\b[VS]\s+(\d+)\s+punti\b/i)?.[1] || 0);
    const score = trailingScoreFromMatchText(text);

    const self = selfDescriptorFromMatchText(
      text,
      clean(anchor.innerText || anchor.textContent || ''),
      score
    );

    if (self && !selfDescriptor) selfDescriptor = self;

    const result = resultLetter === 'V' ? 'W' : resultLetter === 'S' ? 'L' : '';
    const metadata = matchMetadataFromDom(card);

    const baseKey = [
      identity.externalId,
      opponentId,
      result,
      points,
      score,
      clean(text).slice(0, 800),
    ].join('|');

    const ordinal = (duplicateCounts.get(baseKey) || 0) + 1;
    duplicateCounts.set(baseKey, ordinal);

    matches.push({
      externalKey: `tt-match|${baseKey}|${ordinal}`,
      date: metadata.date,
      result,
      points,
      opponentName: opponent.name,
      opponentExternalId: opponentId,
      opponentUrl: `${location.origin}/giocatore/${opponentId}`,
      opponentFitpRanking: opponent.fitpRanking,
      opponentCategory: opponent.category,
      opponentRegion: opponent.region,
      opponentProvince: opponent.province,
      opponentClub: opponent.club,
      score,
      tournament: metadata.tournament,
      surface: metadata.surface,
      round: metadata.round,
      raw: text.slice(0, 1200),
      sourceContext: {
        date: metadata.dateContext,
        round: metadata.roundContext,
      },
    });
  }

  const profile = {
    externalId: identity.externalId,
    externalUrl: identity.externalUrl,
    name: selfDescriptor?.name || identity.name,
    fitpRanking: selfDescriptor?.fitpRanking || '',
    fitpPoints: '',
    category: selfDescriptor?.category || '',
    club: selfDescriptor?.club || '',
    region: selfDescriptor?.region || '',
    province: selfDescriptor?.province || '',
    handedness: '',
    backhand: '',
    preferredSurface: '',
    stats: {},
    equipment: {},
    strengths: {},
    matches,
    matchHistorySource: 'TennisTalker · pagina Partite',
  };

  return {
    ok: Boolean(profile.externalId && profile.name && matches.length),
    version: TPOS_COMPANION_VERSION,
    kind: 'profile',
    mode: 'matches',
    scannedAt: new Date().toISOString(),
    page: {
      url: location.href,
      title: document.title,
    },
    profile,
    diagnostics: {
      selfExternalId: identity.externalId,
      selfNameFromTitle: identity.name,
      selfDescriptor,
      playerAnchorsSeen: opponentAnchors.length,
      matchCardsRecognized: matches.length,
      matchesWithDate: matches.filter(match => match.date).length,
      matchesWithTournament: matches.filter(match => match.tournament).length,
      matchesWithSurface: matches.filter(match => match.surface).length,
      firstMatches: matches.slice(0, 8),
      rejected,
    },
    error: matches.length
      ? ''
      : 'Nessun match riconosciuto nella pagina Partite.',
  };
}

async function scanTennisTalkerPlayerProfile() {
  const externalId = tennisTalkerPlayerId();
  if (!externalId) {
    return {
      ok: false,
      error: 'La pagina corrente non è un profilo giocatore TennisTalker.',
    };
  }

  const lines = pageLines();
  const title = clean(document.title);

  const titleName = normalizePlayerName(title.split('|')[0] || '');
  const fitpRanking =
    title.match(/Classifica:\s*([1-4]\.(?:NC|[1-9]))/i)?.[1]?.toUpperCase()
    || firstValueAfterLabel(lines, 'Classifica', value => /^[1-4]\.(?:NC|[1-9])$/i.test(value));

  const category =
    title.match(/Categoria\s+(U(?:08|10|12|14|16|18)|NOR|NOF|O\d{2})/i)?.[1]?.toUpperCase()
    || lines.find(value => /^(?:U(?:08|10|12|14|16|18)|NOR|NOF|O\d{2})$/i.test(value))
    || '';

  const locationMatch = title.match(/\s-\s([A-Z]{3})\s*\(([A-Z]{2})\)\s-\s/i);
  const categoryClubMatch = title.match(
    /Categoria\s+(?:U(?:08|10|12|14|16|18)|NOR|NOF|O\d{2})\s+-\s+(.+?)\s+-\s+[A-Z]{3}\s*\([A-Z]{2}\)\s+-/i
  );

  const club =
    clean(categoryClubMatch?.[1] || '')
    || firstValueAfterLabel(lines, 'Circolo');

  const region = clean(locationMatch?.[1] || '');
  const province = clean(locationMatch?.[2] || '');

  const fitpPoints = firstValueAfterLabel(
    lines,
    'Punti FITP',
    value => /^\d+(?:[.,]\d+)?$/.test(value)
  );

  const winRate = firstValueAfterLabel(
    lines,
    'Vittorie',
    value => /^\d{1,3}%$/.test(value)
  );

  const wins = firstValueAfterLabel(
    lines,
    'Partite vinte',
    value => /^\d+$/.test(value)
  );

  const losses = firstValueAfterLabel(
    lines,
    'Partite perse',
    value => /^\d+$/.test(value)
  );

  const bestRanking = firstValueAfterLabel(lines, 'Massima classifica raggiunta');

  const handedness = firstValueAfterLabel(lines, 'Mano preferita');
  const preferredSurface = firstValueAfterLabel(lines, 'Superficie preferita');
  const racketBrand = firstValueAfterLabel(lines, 'Brand racchetta');
  const backhand = normalizeBackhand(firstValueAfterLabel(lines, 'Tipo di rovescio'));
  const shoeBrand = firstValueAfterLabel(lines, 'Brand scarpe');
  const clothingBrand = firstValueAfterLabel(lines, 'Brand abbigliamento');

  const strengths = parseStrengths(lines);

  const visitCount =
    lines.find(value => /^NUMERO DI VISITE:\s*\d+$/i.test(value))
      ?.match(/(\d+)$/)?.[1]
    || '';

  const profile = {
    externalId,
    externalUrl: `${location.origin}/giocatore/${externalId}`,
    name: titleName,
    fitpRanking: clean(fitpRanking),
    fitpPoints: clean(fitpPoints),
    category: clean(category).toUpperCase(),
    club,
    region,
    province,
    handedness: clean(handedness),
    backhand,
    preferredSurface: clean(preferredSurface),
    stats: {
      winRate: clean(winRate),
      wins: Number(wins) || null,
      losses: Number(losses) || null,
      bestRanking: clean(bestRanking),
      visitCount: Number(visitCount) || null,
    },
    equipment: {
      racketBrand: clean(racketBrand),
      shoeBrand: clean(shoeBrand),
      clothingBrand: clean(clothingBrand),
    },
    strengths,
    matches: [],
    matchHistorySource: '',
  };

  const fullHistory = await fetchFullMatchHistory(profile);
  const recentMatches = parseRecentMatchesFromOverview(profile);

  if (fullHistory.matches.length) {
    profile.matches = fullHistory.matches;
    profile.matchHistorySource = 'TennisTalker · pagina Partite';
  } else {
    profile.matches = recentMatches;
    profile.matchHistorySource = recentMatches.length
      ? 'TennisTalker · Ultime partite'
      : '';
  }

  const meaningful = Boolean(
    profile.name
    && (
      profile.fitpRanking
      || profile.category
      || profile.club
      || profile.externalId
    )
  );

  return {
    ok: meaningful,
    version: TPOS_COMPANION_VERSION,
    kind: 'profile',
    scannedAt: new Date().toISOString(),
    page: {
      url: location.href,
      title: document.title,
    },
    profile,
    diagnostics: {
      lineCount: lines.length,
      title,
      strengthsSectionFound: lines.includes('Punti di Forza'),
      recentMatchesFound: recentMatches.length,
      fullHistory: {
        ok: fullHistory.ok,
        url: fullHistory.url,
        status: fullHistory.status,
        htmlLength: fullHistory.htmlLength || 0,
        matchesFound: fullHistory.matches.length,
        reason: fullHistory.reason || '',
      },
      importedMatches: profile.matches.length,
      matchHistorySource: profile.matchHistorySource,
    },
    error: meaningful ? '' : 'Profilo TennisTalker non riconosciuto.',
  };
}



function tennisTalkerMode() {
  if (!isTennisTalkerPage()) return 'unsupported';

  if (
    /^\/giocatore\/\d+\/partite\/?$/i.test(location.pathname)
    || /^\/profilo\/partite\/?$/i.test(location.pathname)
  ) return 'matches';
  if (/^\/giocatore\/\d+\/?$/i.test(location.pathname)) return 'profile';
  if (/^\/classifiche\/?$/i.test(location.pathname)) return 'ranking';

  return 'unsupported';
}

function makePendingPayload(result) {
  const importId = crypto.randomUUID
    ? crypto.randomUUID()
    : `import-${Date.now()}-${Math.random().toString(16).slice(2)}`;

  if (result?.mode === 'matches') {
    return {
      importId,
      kind: 'matches',
      source: 'TennisTalker',
      sourceMode: 'companion-inline',
      sourceUrl: result.page?.url || location.href,
      scannedAt: result.scannedAt || new Date().toISOString(),
      profile: result.profile,
    };
  }

  if (result?.kind === 'profile') {
    return {
      importId,
      kind: 'profile',
      source: 'TennisTalker',
      sourceMode: 'companion-inline',
      sourceUrl: result.page?.url || location.href,
      scannedAt: result.scannedAt || new Date().toISOString(),
      profile: result.profile,
    };
  }

  return {
    importId,
    kind: 'ranking',
    source: 'TennisTalker',
    sourceMode: 'companion-inline',
    sourceUrl: result?.page?.url || location.href,
    scannedAt: result?.scannedAt || new Date().toISOString(),
    categories: result?.categories || [],
    players: result?.players || [],
  };
}

async function openTposFromContentScript(route = 'opponents') {
  const safeRoute = route === 'competition' ? 'competition' : 'opponents';

  try {
    const response = await chrome.runtime.sendMessage({
      type: 'TPOS_OPEN_APP',
      route: safeRoute,
    });
    if (response?.ok) return true;
  } catch {
    // Fall through to a normal browser navigation.
  }

  const base = DEFAULT_TPOS_URL.split('#')[0];
  const opened = window.open(`${base}#/${safeRoute}`, '_blank', 'noopener');
  return Boolean(opened);
}

async function queueResultForTpos(result) {
  const validMatches = (
    result?.mode === 'matches'
    && result.profile?.name
    && Array.isArray(result.profile?.matches)
    && result.profile.matches.length
  );

  const validProfile = (
    result?.kind === 'profile'
    && result?.mode !== 'matches'
    && result.profile?.externalId
    && result.profile?.name
  );

  const validRanking = (
    result?.kind !== 'profile'
    && Array.isArray(result?.players)
    && result.players.length
  );

  if (!validMatches && !validProfile && !validRanking) {
    throw new Error(result?.error || 'Nessun dato importabile riconosciuto.');
  }

  const pending = makePendingPayload(result);
  await chrome.storage.local.set({ [PENDING_KEY]: pending });
  await openTposFromContentScript(result?.mode === 'matches' ? 'competition' : 'opponents');

  return pending;
}

function inlinePanelCopy(mode) {
  if (mode === 'ranking') {
    return {
      eyebrow: 'Ranking',
      title: 'Importa Top 50',
      description: 'Leggi la classifica aperta e prepara una snapshot in Opponents.',
      working: 'Leggo la classifica…',
    };
  }

  if (mode === 'profile') {
    return {
      eyebrow: 'Opponent',
      title: 'Aggiorna opponent',
      description: 'Importa o aggiorna il profilo giocatore aperto.',
      working: 'Leggo il profilo…',
    };
  }

  if (mode === 'matches') {
    return {
      eyebrow: 'Storico match',
      title: 'Importa storico match',
      description: 'Importa lo storico partite nel modulo Match di Tennis Player OS.',
      working: 'Leggo le partite…',
    };
  }

  return null;
}

async function scanCurrentTennisTalkerMode(mode) {
  if (mode === 'ranking') {
    const result = scanTennisTalkerPage();
    result.kind = 'ranking';
    result.mode = 'ranking';
    return result;
  }

  if (mode === 'profile') {
    const result = await scanTennisTalkerPlayerProfile();
    result.kind = 'profile';
    result.mode = 'profile';
    return result;
  }

  if (mode === 'matches') {
    const result = scanTennisTalkerMatchesPage();
    result.kind = 'profile';
    result.mode = 'matches';
    return result;
  }

  return {
    ok: false,
    error: 'Pagina TennisTalker non supportata.',
  };
}

function ensureTposPresenceMarker() {
  if (!isTposPage()) return;

  let marker = document.getElementById('tpos-companion-presence');
  if (!marker) {
    marker = document.createElement('div');
    marker.id = 'tpos-companion-presence';
    marker.hidden = true;
    marker.setAttribute('aria-hidden', 'true');
    document.documentElement.appendChild(marker);
  }

  marker.dataset.version = TPOS_COMPANION_VERSION;
  marker.dataset.ready = 'true';
  marker.dataset.capabilities = 'ranking,profile,matches,inline-ui';
  marker.dataset.updatedAt = new Date().toISOString();
}

function removeTennisTalkerPanel() {
  document.getElementById('tpos-companion-panel-host')?.remove();
}

function renderTennisTalkerPanel() {
  if (!isTennisTalkerPage()) return;

  const mode = tennisTalkerMode();
  const copy = inlinePanelCopy(mode);

  if (!copy) {
    removeTennisTalkerPanel();
    return;
  }

  let host = document.getElementById('tpos-companion-panel-host');

  if (!host) {
    host = document.createElement('div');
    host.id = 'tpos-companion-panel-host';
    host.style.position = 'fixed';
    host.style.right = '18px';
    host.style.bottom = '18px';
    host.style.zIndex = '2147483646';
    document.documentElement.appendChild(host);
  }

  const root = host.shadowRoot || host.attachShadow({ mode: 'open' });

  root.innerHTML = `
    <style>
      :host { all: initial; }
      .card {
        box-sizing: border-box;
        width: min(330px, calc(100vw - 28px));
        border: 1px solid rgba(21, 42, 70, .16);
        border-radius: 16px;
        background: rgba(255,255,255,.98);
        box-shadow: 0 16px 45px rgba(17, 35, 59, .18);
        padding: 13px;
        color: #17263a;
        font: 13px/1.35 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      }
      .top { display:flex; align-items:flex-start; justify-content:space-between; gap:10px; }
      .brand { display:flex; align-items:center; gap:9px; min-width:0; }
      .mark {
        width:34px; height:34px; flex:0 0 auto; display:grid; place-items:center;
        border-radius:11px; background:#132f50; color:white; font-size:17px;
      }
      .eyebrow {
        color:#6d7d91; text-transform:uppercase; letter-spacing:.08em;
        font-weight:800; font-size:10px;
      }
      .name { margin-top:2px; font-weight:850; font-size:13px; }
      .close {
        border:0; background:transparent; color:#8190a4; cursor:pointer;
        font-size:18px; line-height:1; padding:2px 4px;
      }
      .copy { margin:9px 0 11px; color:#637287; font-size:12px; }
      .button {
        width:100%; border:0; border-radius:11px; background:#163a61; color:#fff;
        padding:10px 12px; font-weight:850; cursor:pointer; font-size:12px;
      }
      .button:hover { filter:brightness(.96); }
      .button:disabled { opacity:.6; cursor:wait; }
      .status { min-height:16px; margin-top:8px; color:#66768b; font-size:11px; }
      .status.success { color:#26704f; }
      .status.error { color:#9b3f4a; }
      .footer { margin-top:7px; color:#98a2b0; font-size:9px; text-align:right; }
    </style>
    <div class="card">
      <div class="top">
        <div class="brand">
          <div class="mark">🎾</div>
          <div>
            <div class="eyebrow">${copy.eyebrow}</div>
            <div class="name">Tennis Player OS</div>
          </div>
        </div>
        <button class="close" type="button" title="Nascondi">×</button>
      </div>
      <div class="copy">${copy.description}</div>
      <button class="button" type="button">${copy.title}</button>
      <div class="status" aria-live="polite"></div>
      <div class="footer">Companion v${TPOS_COMPANION_VERSION}</div>
    </div>
  `;

  const close = root.querySelector('.close');
  const button = root.querySelector('.button');
  const status = root.querySelector('.status');

  close?.addEventListener('click', () => {
    host.remove();
  });

  button?.addEventListener('click', async () => {
    button.disabled = true;
    status.className = 'status';
    status.textContent = copy.working;

    try {
      const result = await scanCurrentTennisTalkerMode(mode);

      if (!result?.ok) {
        throw new Error(result?.error || 'Dati non riconosciuti.');
      }

      const count = mode === 'ranking'
        ? result.players?.length || 0
        : mode === 'matches'
          ? result.profile?.matches?.length || 0
          : 1;

      await queueResultForTpos(result);

      status.className = 'status success';
      status.textContent = mode === 'ranking'
        ? `${count} giocatori letti. Apro Tennis Player OS…`
        : mode === 'matches'
          ? `${count} match letti. Apro Tennis Player OS…`
          : 'Profilo letto. Apro Tennis Player OS…';
    } catch (error) {
      status.className = 'status error';
      status.textContent = error?.message || String(error);
      button.disabled = false;
    }
  });
}

function setupTennisTalkerInlineUi() {
  if (!isTennisTalkerPage()) return;

  renderTennisTalkerPanel();

  let lastUrl = location.href;

  window.setInterval(() => {
    if (location.href === lastUrl) return;
    lastUrl = location.href;
    window.setTimeout(renderTennisTalkerPanel, 250);
  }, 500);
}

async function deliverPendingToMailbox() {
  if (!isTposPage()) return false;

  const result = await chrome.storage.local.get(PENDING_KEY);
  const pending = result?.[PENDING_KEY];

  const validRanking = (
    pending?.kind === 'ranking'
    && Array.isArray(pending.players)
    && pending.players.length
  );

  const validProfile = (
    pending?.kind === 'profile'
    && pending.profile
    && pending.profile.externalId
  );

  const validMatches = (
    pending?.kind === 'matches'
    && pending.profile
    && pending.profile.name
    && Array.isArray(pending.profile.matches)
    && pending.profile.matches.length
  );

  // Backward compatibility for v0.2.x ranking payloads without explicit kind.
  const legacyRanking = (
    !pending?.kind
    && Array.isArray(pending?.players)
    && pending.players.length
  );

  if (!pending?.importId || (!validRanking && !validProfile && !validMatches && !legacyRanking)) {
    return false;
  }

  let box = document.getElementById('tpos-companion-mailbox');

  if (!box) {
    box = document.createElement('div');
    box.id = 'tpos-companion-mailbox';
    box.hidden = true;
    box.setAttribute('aria-hidden', 'true');
    document.documentElement.appendChild(box);
  }

  box.textContent = JSON.stringify(pending);
  box.dataset.status = 'pending';
  box.dataset.importId = pending.importId;
  box.dataset.updatedAt = new Date().toISOString();

  return true;
}

async function reconcileMailboxResult() {
  if (!isTposPage()) return;

  const box = document.getElementById('tpos-companion-mailbox');
  if (!box || box.dataset.status !== 'finished') return;

  const result = await chrome.storage.local.get(PENDING_KEY);
  const pending = result?.[PENDING_KEY];

  if (!pending || pending.importId !== box.dataset.importId) return;

  await chrome.storage.local.remove(PENDING_KEY);
  box.remove();
}


chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === 'TPOS_DIAGNOSTIC_STATUS') {
    const box = document.getElementById('tpos-companion-mailbox');
    const dialog = document.getElementById('opp-companion-import-dialog')
      || document.getElementById('match-companion-import-dialog');
    const scripts = [...document.scripts].map(script => script.src).filter(Boolean);
    const resources = performance.getEntriesByType('resource')
      .map(entry => entry.name)
      .filter(name => /opponentsCompanionBridge|opponentsUI|matchUI|bootstrap\.js/i.test(name));

    let pageScan = null;

    if (
      isTennisTalkerPage()
      && (
        /^\/giocatore\/\d+\/partite\/?$/i.test(location.pathname)
        || /^\/profilo\/partite\/?$/i.test(location.pathname)
      )
    ) {
      try {
        const scan = scanTennisTalkerMatchesPage();
        pageScan = {
          ok: Boolean(scan?.ok),
          error: scan?.error || '',
          profileName: scan?.profile?.name || '',
          externalId: scan?.profile?.externalId || '',
          matchCount: Array.isArray(scan?.profile?.matches) ? scan.profile.matches.length : 0,
          playerAnchorsSeen: scan?.diagnostics?.playerAnchorsSeen ?? null,
          matchCardsRecognized: scan?.diagnostics?.matchCardsRecognized ?? null,
          matchesWithDate: scan?.diagnostics?.matchesWithDate ?? null,
          firstMatches: scan?.diagnostics?.firstMatches?.slice?.(0, 3) || [],
          rejected: scan?.diagnostics?.rejected?.slice?.(0, 5) || [],
        };
      } catch (error) {
        pageScan = {
          ok: false,
          error: error?.message || String(error),
        };
      }
    }

    sendResponse({
      ok: true,
      companionVersion: TPOS_COMPANION_VERSION,
      capabilities: ['ranking', 'profile', 'matches', 'inline-ui'],
      inlinePanelPresent: Boolean(document.getElementById('tpos-companion-panel-host')),
      presenceMarkerPresent: Boolean(document.getElementById('tpos-companion-presence')),
      location: {
        hostname: location.hostname,
        pathname: location.pathname,
        hash: location.hash,
        href: location.href,
      },
      readyState: document.readyState,
      isTennisTalkerPage: isTennisTalkerPage(),
      isTposPage: isTposPage(),
      opponentsRootPresent: Boolean(document.querySelector('[data-opponents-root]')),
      mailbox: box ? {
        present: true,
        status: box.dataset.status || '',
        importId: box.dataset.importId || '',
        outcome: box.dataset.outcome || '',
        textLength: (box.textContent || '').length,
      } : {
        present: false,
      },
      importDialogPresent: Boolean(dialog),
      companionBridgeScriptTagPresent: scripts.some(src => /opponentsCompanionBridge\.js/i.test(src)),
      relevantResources: resources.slice(-10),
      pageScan,
    });
    return true;
  }

  if (message?.type === 'TPOS_SCAN_TENNISTALKER_MATCHES') {
    if (!isTennisTalkerPage()) {
      sendResponse({ ok: false, error: 'La scheda attiva non è TennisTalker.' });
      return true;
    }

    try {
      sendResponse(scanTennisTalkerMatchesPage());
    } catch (error) {
      sendResponse({
        ok: false,
        error: error?.message || String(error),
      });
    }

    return true;
  }

  if (message?.type === 'TPOS_SCAN_TENNISTALKER_PROFILE') {
    if (!isTennisTalkerPage()) {
      sendResponse({ ok: false, error: 'La scheda attiva non è TennisTalker.' });
      return true;
    }

    void scanTennisTalkerPlayerProfile()
      .then(result => sendResponse(result))
      .catch(error => {
        sendResponse({
          ok: false,
          error: error?.message || String(error),
        });
      });

    return true;
  }

  if (message?.type === 'TPOS_SCAN_TENNISTALKER') {
    if (!isTennisTalkerPage()) {
      sendResponse({ ok: false, error: 'La scheda attiva non è TennisTalker.' });
      return true;
    }

    try {
      sendResponse(scanTennisTalkerPage());
    } catch (error) {
      sendResponse({
        ok: false,
        error: error?.message || String(error),
      });
    }
    return true;
  }

  if (message?.type === 'TPOS_COMPANION_DELIVER_PENDING' && isTposPage()) {
    void deliverPendingToMailbox()
      .then(delivered => sendResponse({ ok: true, delivered }));
    return true;
  }

  return false;
});

if (isTposPage()) {
  ensureTposPresenceMarker();

  const tick = async () => {
    ensureTposPresenceMarker();
    await reconcileMailboxResult();
    await deliverPendingToMailbox();
  };

  const observer = new MutationObserver(() => {
    void reconcileMailboxResult();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['data-status'],
  });

  window.setInterval(() => {
    void tick();
  }, 1000);

  window.setTimeout(() => {
    void tick();
  }, 100);
}


if (isTennisTalkerPage()) {
  setupTennisTalkerInlineUi();
}
