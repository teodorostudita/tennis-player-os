const DEFAULT_TPOS_URL = 'https://tennis.polidorionline.it/#/opponents';

function isTposUrl(url = '') {
  try {
    const parsed = new URL(url);
    return (
      parsed.hostname === 'tennis.polidorionline.it'
      || (
        parsed.hostname === 'teodorostudita.github.io'
        && parsed.pathname.toLowerCase().startsWith('/tennis-player-os')
      )
      || parsed.hostname === 'localhost'
      || parsed.hostname === '127.0.0.1'
    );
  } catch {
    return false;
  }
}

async function findOrOpenTpos(route = 'opponents') {
  const safeRoute = route === 'competition' ? 'competition' : 'opponents';
  const tabs = await chrome.tabs.query({});
  const existing = tabs.find(tab => isTposUrl(tab.url || ''));

  if (existing?.id) {
    const base = String(existing.url || '').split('#')[0];
    const updated = await chrome.tabs.update(existing.id, {
      active: true,
      url: `${base}#/${safeRoute}`,
    });

    try {
      await chrome.tabs.sendMessage(existing.id, {
        type: 'TPOS_DIAGNOSTIC_STATUS',
      });
    } catch {
      await chrome.tabs.reload(existing.id);
    }

    if (existing.windowId) {
      try {
        await chrome.windows.update(existing.windowId, { focused: true });
      } catch {
        // Focusing is helpful but not required.
      }
    }

    window.setTimeout?.(() => {}, 0);
    return updated?.id || existing.id;
  }

  const created = await chrome.tabs.create({
    url: `${DEFAULT_TPOS_URL.split('#')[0]}#/${safeRoute}`,
    active: true,
  });

  return created.id;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== 'TPOS_OPEN_APP') return false;

  void findOrOpenTpos(message?.route)
    .then(tabId => {
      sendResponse({ ok: true, tabId });
    })
    .catch(error => {
      sendResponse({
        ok: false,
        error: error?.message || String(error),
      });
    });

  return true;
});
