# Tennis Player OS Companion 1.0.2

Companion browser per Tennis Player OS.

## Uso normale
Dopo l'installazione non serve aprire l'icona dell'estensione.

Sulle pagine supportate di TennisTalker compare un pannello **Tennis Player OS**:
- Classifiche → **Importa Top 50**
- Profilo giocatore → **Aggiorna opponent**
- Pagina Partite → **Importa storico match**

Il Companion prepara i dati e porta l'utente in Tennis Player OS, dove l'importazione viene confermata prima del salvataggio.

## Privacy
- non legge né salva username o password TennisTalker;
- usa la sessione browser già autenticata dall'utente;
- non invia i dati a servizi terzi propri del Companion;
- conserva temporaneamente il payload da importare in `chrome.storage.local`;
- il payload viene rimosso dopo la conclusione dell'importazione in Tennis Player OS.

Il popup dell'estensione resta disponibile come strumento manuale e diagnostico.


## v1.0.2
- Supporto alla pagina autenticata `/profilo/partite`.
- Lo storico match viene inviato direttamente al modulo Match di TPOS.


## v1.0.2
- Parser Match più tollerante sui record compatti della pagina `/profilo/partite`.
- Riconoscimento card non più vincolato al risultato come primo testo del riquadro.
- Reload automatico di TPOS se il content script non è presente dopo un aggiornamento dell'estensione.
- Diagnostica estesa con `pageScan`.
