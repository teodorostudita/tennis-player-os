
const DEFAULT_TPOS_URL = 'https://tennis.polidorionline.it/#/opponents';
const PENDING_KEY = 'tposPendingImport.v1';
let lastResult = null;
let activeMode = 'ranking';

const $ = selector => document.querySelector(selector);
const pageState = $('#page-state');
const scanButton = $('#scan');
const sendButton = $('#send-tpos');
const summary = $('#summary');
const actions = $('#actions');
const preview = $('#preview');
const intro = document.querySelector('.intro');

function setState(message, kind = 'neutral') {
  pageState.textContent = message;
  pageState.className = `state ${kind}`;
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

async function sendToPage(message) {
  const tab = await activeTab();
  if (!tab?.id) throw new Error('Scheda attiva non disponibile.');
  return chrome.tabs.sendMessage(tab.id, message);
}

function isTennisTalker(url = '') {
  try {
    const host = new URL(url).hostname;
    return host === 'www.tennistalker.it' || host === 'tennistalker.it';
  } catch {
    return false;
  }
}

function pageMode(url = '') {
  try {
    const parsed = new URL(url);
    const path = parsed.pathname;

    if (
      /^\/giocatore\/\d+\/partite\/?$/i.test(path)
      || /^\/profilo\/partite\/?$/i.test(path)
    ) return 'matches';
    if (/^\/giocatore\/\d+\/?$/i.test(path)) return 'profile';
    if (/^\/classifiche\/?$/i.test(path)) return 'ranking';

    return 'unsupported';
  } catch {
    return 'unsupported';
  }
}

function isTposUrl(url = '') {
  try {
    const parsed = new URL(url);
    return (
      parsed.hostname === 'tennis.polidorionline.it'
      || (parsed.hostname === 'teodorostudita.github.io'
          && parsed.pathname.toLowerCase().startsWith('/tennis-player-os'))
      || parsed.hostname === 'localhost'
      || parsed.hostname === '127.0.0.1'
    );
  } catch {
    return false;
  }
}

function escapeHtml(value = '') {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function renderRanking(result) {
  summary.innerHTML = `
    <div class="metric"><span>Giocatori letti</span><strong>${result.count || 0}</strong></div>
    <div class="metric"><span>Categorie</span><strong>${escapeHtml(result.categories?.join(', ') || '—')}</strong></div>
    <div class="metric"><span>Filtrati</span><strong>${escapeHtml(result.page?.filteredCount || '—')}</strong></div>
  `;

  preview.innerHTML = result.players?.length
    ? result.players.slice(0, 50).map(player => `
        <div class="row">
          <div class="rank">#${player.rank || '—'}</div>
          <div class="player">
            <strong>${escapeHtml(player.name || '—')}</strong>
            <small>${escapeHtml([player.category, player.region, player.province, player.club].filter(Boolean).join(' · '))}</small>
          </div>
          <div class="fitp">${escapeHtml(player.fitpRanking || '—')}</div>
        </div>
      `).join('')
    : `<div class="row"><div class="rank">—</div><div class="player"><strong>Nessun giocatore riconosciuto</strong></div><div class="fitp"></div></div>`;
}

function renderProfile(result) {
  const profile = result.profile || {};
  const stats = profile.stats || {};

  summary.innerHTML = `
    <div class="metric"><span>FITP</span><strong>${escapeHtml(profile.fitpRanking || '—')}</strong></div>
    <div class="metric"><span>Punti</span><strong>${escapeHtml(profile.fitpPoints || '—')}</strong></div>
    <div class="metric"><span>Match letti</span><strong>${escapeHtml(profile.matches?.length || 0)}</strong></div>
  `;

  const details = [
    ['Categoria', profile.category],
    ['Club', profile.club],
    ['Area', [profile.region, profile.province].filter(Boolean).join(' · ')],
    ['Mano', profile.handedness],
    ['Rovescio', profile.backhand],
    ['Superficie', profile.preferredSurface],
    ['Vittorie', stats.winRate],
    ['W / L', (Number.isFinite(stats.wins) || Number.isFinite(stats.losses))
      ? `${stats.wins ?? '—'} / ${stats.losses ?? '—'}`
      : ''],
    ['Best ranking', stats.bestRanking],
    ['Storico match', profile.matchHistorySource
      ? `${profile.matches?.length || 0} · ${profile.matchHistorySource}`
      : ''],
  ].filter(([, value]) => value);

  preview.innerHTML = `
    <div class="row">
      <div class="rank">TT</div>
      <div class="player">
        <strong>${escapeHtml(profile.name || '—')}</strong>
        <small>ID ${escapeHtml(profile.externalId || '—')}</small>
      </div>
      <div class="fitp">${escapeHtml(profile.fitpRanking || '—')}</div>
    </div>
    ${details.map(([label, value]) => `
      <div class="row">
        <div class="rank"></div>
        <div class="player"><strong>${escapeHtml(label)}</strong><small>${escapeHtml(value)}</small></div>
        <div class="fitp"></div>
      </div>
    `).join('')}
  `;
}

function render(result) {
  lastResult = result;
  summary.classList.remove('hidden');
  actions.classList.remove('hidden');
  preview.classList.remove('hidden');

  const valid = result.mode === 'matches'
    ? Boolean(result.profile?.name && result.profile?.matches?.length)
    : result.kind === 'profile'
      ? Boolean(result.profile?.externalId && result.profile?.name)
      : Boolean(result.players?.length);

  sendButton.classList.toggle('hidden', !valid);

  if (result.mode === 'matches') {
    sendButton.textContent = 'Invia storico match a Tennis Player OS';
  } else if (result.kind === 'profile') {
    sendButton.textContent = 'Invia profilo a Tennis Player OS';
  } else {
    sendButton.textContent = 'Invia ranking a Tennis Player OS';
  }

  if (result.kind === 'profile') renderProfile(result);
  else renderRanking(result);
}

async function copyText(value, message) {
  await navigator.clipboard.writeText(value);
  setState(message, 'success');
}

async function scan() {
  scanButton.disabled = true;
  setState('Lettura della pagina in corso…');

  try {
    const messageType = activeMode === 'matches'
      ? 'TPOS_SCAN_TENNISTALKER_MATCHES'
      : activeMode === 'profile'
        ? 'TPOS_SCAN_TENNISTALKER_PROFILE'
        : 'TPOS_SCAN_TENNISTALKER';

    const result = await sendToPage({ type: messageType });
    if (!result?.ok) throw new Error(result?.error || 'Parser non disponibile.');

    if (!result.kind) result.kind = activeMode;
    render(result);

    if (activeMode === 'matches') {
      const count = result.profile?.matches?.length || 0;
      setState(
        count
          ? `Letti ${count} match di ${result.profile?.name || 'giocatore'}.`
          : 'Nessun match riconosciuto.',
        count ? 'success' : 'error',
      );
    } else if (activeMode === 'profile') {
      setState(`Profilo letto: ${result.profile?.name || 'giocatore'}.`, 'success');
    } else {
      setState(
        result.count
          ? `Letti ${result.count} giocatori dalla pagina corrente.`
          : 'Nessun giocatore riconosciuto.',
        result.count ? 'success' : 'error',
      );
    }
  } catch (error) {
    setState(
      `Impossibile leggere la pagina: ${error?.message || String(error)}. Ricarica TennisTalker se hai appena aggiornato l’estensione.`,
      'error',
    );
  } finally {
    scanButton.disabled = false;
  }
}

async function findOrOpenTpos(route = 'opponents') {
  const safeRoute = route === 'competition' ? 'competition' : 'opponents';
  const tabs = await chrome.tabs.query({});
  const existing = tabs.find(tab => isTposUrl(tab.url || ''));

  if (existing?.id) {
    const base = String(existing.url || '').split('#')[0];
    await chrome.tabs.update(existing.id, { active: true, url: `${base}#/${safeRoute}` });

    try {
      await chrome.tabs.sendMessage(existing.id, {
        type: 'TPOS_DIAGNOSTIC_STATUS',
      });
    } catch {
      await chrome.tabs.reload(existing.id);
    }

    if (existing.windowId) {
      await chrome.windows.update(existing.windowId, { focused: true });
    }
    return existing.id;
  }

  const created = await chrome.tabs.create({ url: `${DEFAULT_TPOS_URL.split('#')[0]}#/${safeRoute}`, active: true });
  return created.id;
}

sendButton.addEventListener('click', async () => {
  const isMatches = lastResult?.mode === 'matches';
  const isProfile = lastResult?.kind === 'profile' && !isMatches;
  const valid = isMatches
    ? Boolean(lastResult?.profile?.name && lastResult?.profile?.matches?.length)
    : isProfile
      ? Boolean(lastResult?.profile?.externalId)
      : Boolean(lastResult?.players?.length);

  if (!valid) return;

  sendButton.disabled = true;
  setState('Preparo il trasferimento a Tennis Player OS…');

  try {
    const importId = crypto.randomUUID
      ? crypto.randomUUID()
      : `import-${Date.now()}`;

    const pending = isMatches
      ? {
          importId,
          kind: 'matches',
          source: 'TennisTalker',
          sourceMode: 'companion',
          sourceUrl: lastResult.page?.url || '',
          scannedAt: lastResult.scannedAt || new Date().toISOString(),
          profile: lastResult.profile,
        }
      : isProfile
        ? {
            importId,
            kind: 'profile',
            source: 'TennisTalker',
            sourceMode: 'companion',
            sourceUrl: lastResult.page?.url || '',
            scannedAt: lastResult.scannedAt || new Date().toISOString(),
            profile: lastResult.profile,
          }
        : {
          importId,
          kind: 'ranking',
          source: 'TennisTalker',
          sourceMode: 'companion',
          sourceUrl: lastResult.page?.url || '',
          scannedAt: lastResult.scannedAt || new Date().toISOString(),
          categories: lastResult.categories || [],
          players: lastResult.players || [],
        };

    await chrome.storage.local.set({ [PENDING_KEY]: pending });
    const tabId = await findOrOpenTpos(isMatches ? 'competition' : 'opponents');

    window.setTimeout(() => {
      chrome.tabs.sendMessage(tabId, {
        type: 'TPOS_COMPANION_DELIVER_PENDING',
      }).catch(() => {});
    }, 500);

    setState(
      lastResult?.mode === 'matches'
        ? 'Storico match inviato. Conferma l’aggiornamento in Tennis Player OS.'
        : isProfile
          ? 'Profilo inviato. Conferma creazione/aggiornamento in Tennis Player OS.'
          : 'Ranking inviato. Conferma l’importazione in Tennis Player OS.',
      'success',
    );
  } catch (error) {
    setState(`Invio non riuscito: ${error?.message || String(error)}`, 'error');
    sendButton.disabled = false;
  }
});

$('#copy-json').addEventListener('click', () => {
  if (!lastResult) return;
  void copyText(JSON.stringify(lastResult, null, 2), 'JSON copiato negli appunti.');
});

$('#copy-debug').addEventListener('click', () => {
  if (!lastResult) return;
  const data = lastResult.kind === 'profile'
    ? {
        page: lastResult.page,
        profile: lastResult.profile,
        diagnostics: lastResult.diagnostics || {},
      }
    : {
        page: lastResult.page,
        count: lastResult.count,
        categories: lastResult.categories,
        diagnostics: lastResult.diagnostics || [],
      };

  void copyText(JSON.stringify(data, null, 2), 'Diagnostica copiata negli appunti.');
});

async function diagnosticReport() {
  const report = {
    generatedAt: new Date().toISOString(),
    extensionVersion: chrome.runtime.getManifest().version,
    storage: {},
    tabs: [],
  };

  try {
    const storage = await chrome.storage.local.get(PENDING_KEY);
    const pending = storage?.[PENDING_KEY];
    report.storage = pending ? {
      pending: true,
      importId: pending.importId || '',
      kind: pending.kind || (Array.isArray(pending.players) ? 'ranking' : ''),
      playerCount: Array.isArray(pending.players) ? pending.players.length : 0,
      matchCount: Array.isArray(pending.profile?.matches) ? pending.profile.matches.length : 0,
      profileId: pending.profile?.externalId || '',
      profileName: pending.profile?.name || '',
      sourceUrl: pending.sourceUrl || '',
      scannedAt: pending.scannedAt || '',
    } : {
      pending: false,
    };
  } catch (error) {
    report.storage = { error: error?.message || String(error) };
  }

  const tabs = await chrome.tabs.query({});
  const candidates = tabs.filter(tab => {
    const url = tab.url || '';
    return /tennistalker\.it/i.test(url)
      || /tennis\.polidorionline\.it/i.test(url)
      || /teodorostudita\.github\.io/i.test(url)
      || /^http:\/\/(localhost|127\.0\.0\.1)/i.test(url);
  });

  for (const tab of candidates) {
    const item = {
      id: tab.id,
      active: Boolean(tab.active),
      title: tab.title || '',
      url: tab.url || '',
    };

    try {
      const status = await chrome.tabs.sendMessage(tab.id, {
        type: 'TPOS_DIAGNOSTIC_STATUS',
      });
      item.contentScript = status;
    } catch (error) {
      item.contentScript = {
        reachable: false,
        error: error?.message || String(error),
      };
    }

    report.tabs.push(item);
  }

  return report;
}

document.querySelector('#diagnose')?.addEventListener('click', async () => {
  const button = document.querySelector('#diagnose');
  const panel = document.querySelector('#diagnostic-panel');
  const output = document.querySelector('#diagnostic-output');

  button.disabled = true;
  setState('Diagnostica del bridge in corso…');

  try {
    const report = await diagnosticReport();
    output.value = JSON.stringify(report, null, 2);
    panel.classList.remove('hidden');
    setState('Diagnostica completata.', 'success');
  } catch (error) {
    output.value = JSON.stringify({
      fatalError: error?.message || String(error),
    }, null, 2);
    panel.classList.remove('hidden');
    setState('Diagnostica completata con errore.', 'error');
  } finally {
    button.disabled = false;
  }
});

document.querySelector('#copy-diagnostic-report')?.addEventListener('click', async () => {
  const value = document.querySelector('#diagnostic-output')?.value || '';
  if (!value) return;
  await navigator.clipboard.writeText(value);
  setState('Report diagnostico copiato.', 'success');
});



scanButton.addEventListener('click', scan);

(async () => {
  const tab = await activeTab();

  if (!tab || !isTennisTalker(tab.url || '')) {
    setState('Apri prima una pagina TennisTalker.', 'error');
    scanButton.disabled = true;
    return;
  }

  activeMode = pageMode(tab.url || '');

  if (activeMode === 'matches') {
    scanButton.textContent = 'Leggi storico match';
    intro.textContent = 'Leggi lo storico Partite aperto in TennisTalker e invialo direttamente al modulo Match.';
    setState('Pagina Partite TennisTalker rilevata.', 'success');
  } else if (activeMode === 'profile') {
    scanButton.textContent = 'Leggi profilo';
    intro.textContent = 'Leggi il profilo giocatore TennisTalker aperto nel browser e invialo direttamente a Opponents.';
    setState('Profilo TennisTalker rilevato.', 'success');
  } else if (activeMode === 'ranking') {
    scanButton.textContent = 'Leggi classifica';
    intro.textContent = 'Leggi la classifica TennisTalker aperta nel browser e inviala direttamente a Opponents.';
    setState('Pagina Classifiche TennisTalker rilevata.', 'success');
  } else {
    scanButton.textContent = 'Pagina non supportata';
    scanButton.disabled = true;
    sendButton.classList.add('hidden');
    intro.textContent = 'Questa pagina TennisTalker non è riconosciuta come Classifiche, Profilo o Partite.';
    setState('Nessuna importazione disponibile da questa pagina.', 'error');
  }
})();