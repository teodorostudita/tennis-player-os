# Privacy — Tennis Player OS Companion

Tennis Player OS Companion opera localmente nel browser dell'utente.

Il Companion legge esclusivamente le pagine TennisTalker che l'utente apre nel browser per estrarre i dati sportivi necessari all'importazione in Tennis Player OS. Non legge, intercetta o memorizza username, password o altri dati di autenticazione.

I dati selezionati per l'importazione vengono memorizzati temporaneamente in `chrome.storage.local` per consentire il passaggio alla webapp Tennis Player OS. Dopo che Tennis Player OS conclude o annulla l'importazione, il payload temporaneo viene rimosso.

Il Companion non vende dati e non li invia a reti pubblicitarie o servizi di analytics propri dell'estensione.
